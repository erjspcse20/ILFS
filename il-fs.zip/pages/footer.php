<footer>
    <div class="pull-right">
        <div class="footer">
            <p>© 2019 IL & FS. All Rights Reserved . Design by <a href="#">Hindustan Web</a></p>
        </div>
    </div>
    <div class="clearfix"></div>
</footer>