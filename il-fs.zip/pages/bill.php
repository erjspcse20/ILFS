<html">

<head>
</head>

<body>
<table width="1100" style="border:1px solid #333333;" cellspacing="0" cellpadding="0" align="center" >

    
    <tr>
        <td style="height:30px; border-bottom:1px solid;" valign="top">
            <h1 style="text-align:center; font-weight:bolder; text-transform:uppercase; margin-top:3px; margin-bottom:3px;"><b>Tax Invoice</b></h1>
        </td>
    </tr>
    
    <tr>
    <td style="float:right;"><p style="margin:2px; padding:2px;"><strong>INVOICE No. :</strong> DL/JHA/JAN/19/373</p>
    <p style="margin:2px; padding:2px;"><strong>DATE OF ISSUE :</strong> 29-02-2019</p>
    <p style="margin:2px; padding:2px;"><strong>GSTIN No. :</strong>07AABC173770R1ZX</p>
    </td>
   
    </tr>
    <tr>
    
        <td style="height:30px; border-bottom:1px solid;" valign="top">
          <p><img height="80" width="648"  src="images/logo.png" alt="logo"/></p>
        </td>
        
        
        
    </tr>

    <tr>
        <td valign="top">

            <table width="1100px" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="550" style="height:60px; border-right:1px solid;">
                        <p style="font-size:15px; font-weight:bolder; text-align:center; margin:5px; padding:5px;">RECEIVER ( BILL TO )</p>
                        <p style="margin:5px; padding:5px;"><strong>Gautam </strong></p>
                       <p style="margin:5px; padding:5px;">Address/ mobile / email </P>
                        <p style="margin:5px; padding:5px;"><strong>GSTIN No. :</strong><span>055AABC17370R1ZX</span></p>
                       
                    </td>
                    <td width="550" style="height:60px; border-right:1px solid;">
                        <p style="font-size:15px; font-weight:bolder; text-align:center; margin:5px; padding:5px;">CONSIGNEE(DELIVERED TO)</p>
                        <p style="margin:5px; padding:5px;"><strong>Gautam </strong></p>
                       <p style="margin:5px; padding:5px;">Address/ mobile / email </P>
                        <p style="margin:5px; padding:5px;"><strong>GSTIN No. :</strong> <span>055AABC17370R1ZX</span></p>
                       
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <tr>
        <td width="1100">
            <table cellspacing="2" cellpadding="2" width="1100">
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;"><strong>Sr.</strong></td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>HSN/</strong></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>Name of Goods/ Survices Supplied</strong></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>UOM</strong></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>QTY</strong></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>Rate</strong></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>Value</strong></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>Tax%</strong></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>SGST Value</strong></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>Tax%</strong></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>CGST</strong></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>Tax%</strong></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>IGST</strong></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">1</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">12345678</td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">Stone Dust</td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">MT</td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">2.30</td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">667.00</td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">1,534</td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">2.5 %</td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">38.00</td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">2.5 %</td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">38.00</td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">0%</td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">0.000</td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">3</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">3</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">4</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">5</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">6</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">7</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">8</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">9</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">10</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">.</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">.</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"><strong>TOTAL</strong></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">MT</td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">2.30</td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">667.00</td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">1,534</td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">2.5 %</td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">38.00</td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">2.5 %</td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">38.00</td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">0%</td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;">0.000</td>

                </tr>
                <tr>
                    <td style="border-top:1px solid; border-right:1px solid; height:20px; text-align:center;">.</td>
           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                    <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                     <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                      <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                       <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                        <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                         <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                          <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                           <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                             <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>
                            <td style="border-top:1px solid; border-right:1px solid; text-align:center; height:20px;"></td>

                </tr>
                
               
            </table>
        </td>
    </tr>
    
<tr>
<td style="border:1px solid #000000; padding:10px;">
<table>
<tr>
<td style="border:1px solid #000000; padding:10px; width:800px;"><strong>One thousand six hundred ten only</strong></td>
<td style="border:1px solid #000000; padding:10px; width:300px;"><strong>1,610.00</strong></td>
</tr>
</table>
</td>
</tr>
    <tr><td style="height:50px;"></td></tr>

    <tr>
        <td width="1100">
            <table width="1100px" cellspacing="0" cellpadding="0" border="1">
                <tr>
                    <td width="550" style="height:60px;">
                        .
                       
                    </td>
                    <td width="550" style="height:60px; border-right:1px solid;">
    <p style="font-size:15px; font-weight:bolder; text-align:center; margin:5px; padding:5px;">For IL & FS Environmental Infrastructure & Services Ltd.</p>
                        <p style=" padding:5px; margin:30px 5px 5px 5px;">Authorised Signatory</p>
                       
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="1100">
            <table width="1100px" cellspacing="0" cellpadding="0" border="1">
                <tr>
                    <td width="550" style="height:60px;">
                      <p style="font-size:15px; text-align:left; margin:5px; padding:5px;">Benficiary Name : IL & FS Environmental Infrasrtucture & Services Limited.	</p>
                        <p style="font-size:15px; text-align:left; margin:5px; padding:5px;">Current  Account No. : 00880350000129</p>
                          <p style="font-size:15px; text-align:left; margin:5px; padding:5px;">Bank : HDFC BANK NODIA</p>
                            <p style="font-size:15px; text-align:left; margin:5px; padding:5px;">IFSC : Code HDFC000088</p>
                    </td>
                    <td width="550" style="height:60px; border-right:1px solid;">
    <p style="font-size:15px; font-weight:bolder; text-align:center; margin:5px; padding:5px;">NOTE.</p>
    <p>Cheque should be in favour of </p>
    <p><strong>IL & FS Environmental Infrasrtucture & Services Limited.	</strong></p>
  
                       
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    
    

    




  <tr>
  <td>
  <table>
  <td>
  <tr>
  <p align="center">Regisitered Office : 217-A, Ground Floor, Okhla , Phase -3, New Delhi - 110020</p>
  <p align="center">CIN No. : U90001DL2007PLC166554</p>
  </tr>
  </td>
  </table>
  </td>
  </tr>  

</table>



</body>

</html>
